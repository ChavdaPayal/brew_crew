class Brew{
   final String name;
   final String suger;
   final int strength;

   Brew({this.name,this.suger,this.strength});
}